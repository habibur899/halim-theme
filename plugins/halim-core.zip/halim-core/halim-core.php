<?php
/**
 * Plugin Name:       Halim Core
 * Plugin URI:        https://github.com/habibur899/halim-theme
 * Description:       Here is all halim core code.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Habibur Rahaman
 * Author URI:        https://github.com/habibur899
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://github.com/habibur899/halim-theme
 * Text Domain:       halim
 * Domain Path:       /languages
 */

require_once plugin_dir_path( __FILE__ ) . '/inc/acf-options/acf-options.php';
require_once plugin_dir_path( __FILE__ ) . '/inc/acf-options/acf-css.php';
require_once plugin_dir_path( __FILE__ ) . '/inc/acf-options/acf-field.php';
require_once plugin_dir_path( __FILE__ ) . '/inc/cpt/cpt.php';
require_once plugin_dir_path( __FILE__ ) . '/inc/cpt/cpt-taxonomy.php';