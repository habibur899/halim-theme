<?php
if ( function_exists( 'acf_add_options_page' ) ) {

	acf_add_options_page( array(
		'page_title' => __( 'Halim Options', 'halim' ),
		'menu_title' => __( 'Halim Options', 'halim' ),
		'menu_slug'  => 'halim-options',
		'capability' => 'edit_posts',
		'redirect'   => true
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Header', 'halim' ),
		'menu_title'  => __( 'Header', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'About', 'halim' ),
		'menu_title'  => __( 'About', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Faq and Skill', 'halim' ),
		'menu_title'  => __( 'Faq and Skill', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Services', 'halim' ),
		'menu_title'  => __( 'Services', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Team', 'halim' ),
		'menu_title'  => __( 'Team', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Client', 'halim' ),
		'menu_title'  => __( 'Client', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Blog', 'halim' ),
		'menu_title'  => __( 'Blog', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'CTA', 'halim' ),
		'menu_title'  => __( 'CTA', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Contact', 'halim' ),
		'menu_title'  => __( 'Contact', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

	acf_add_options_sub_page( array(
		'page_title'  => __( 'Footer', 'halim' ),
		'menu_title'  => __( 'Footer', 'halim' ),
		'parent_slug' => 'halim-options',
	) );

}