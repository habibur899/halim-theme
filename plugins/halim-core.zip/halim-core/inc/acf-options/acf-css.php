<?php


function acf_css() {
	?>
    <style>
        .header-top {
            background-color: <?php the_field('header_background','option');?>;
        }
        .choose {
            background-image: url("<?php esc_url(the_field('faq_background_image','option')) ?>");
        }
        .testimonial-area {
            background-image: url("<?php esc_url(the_field('client_background_image','option')) ?>");
        }
        .footer-area {
            background-image: url("<?php esc_url(the_field('background_image','option')) ?>");

        }
    </style>
	<?php
}

add_action( 'wp_head', 'acf_css' );